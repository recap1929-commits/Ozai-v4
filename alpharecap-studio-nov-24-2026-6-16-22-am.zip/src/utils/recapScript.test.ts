import test from 'node:test';
import assert from 'node:assert/strict';
import { buildFullRecapBeats, computeLockedVideoRecapSchedule } from './audioSync';
import {
  auditRecapCharacterConsistency,
  buildRecapAutoExpansionPrompt,
  buildRecapCharacterConsistencyPrompt,
  buildRecapDurationAdjustmentPrompt,
  buildRecapMixedNarrationPrompt,
  buildRecapSceneMappings,
  cleanRecapSpokenText,
  countSpokenUnits,
  distributeEditedScriptAcrossBeats,
  estimateMyanmarTextDurationSeconds,
  estimateRecapNarrationCoverage,
  extractVerifiedCharacterClues,
  formatTimestampedTranscriptContext,
  selectRecapBeatsForAutoExpansion,
  validateAndRefineRecapSegments,
  validateRecapQuality,
} from './recapScript';

test('buildRecapMixedNarrationPrompt enforces MIXED narration+dialogue, TARGET_WORDS (not MAX_WORDS), timestamped transcript, and 90% duration', () => {
  const timestampedSegments = [
    { start: 1.2, end: 4.5, text: 'Where did you hide the ledger?' },
    { start: 4.8, end: 8.4, text: 'If you step closer, nobody leaves alive!' },
    { start: 4.8, end: 8.4, text: 'If you step closer, nobody leaves alive!' }, // duplicate echo
  ];

  const { systemInstruction, prompt, targetDurationSeconds } = buildRecapMixedNarrationPrompt({
    durationSeconds: 60,
    transcript: 'Where did you hide the ledger? If you step closer, nobody leaves alive!',
    timestampedSegments,
    voiceStyleName: 'Street Bro',
    voiceStyleTag: 'Natural',
    voiceStyleDesc: 'Conversational',
    speedNote: 'Use TARGET_WORDS per beat.',
    beatListText: '- Beat id="beat_1" [0.00s -> 30.00s, TARGET_WORDS=65]: "Warehouse confrontation"',
    beatCount: 1,
    scenes: [
      {
        index: 0,
        timestamp: 2.0,
        imageUrl: '/api/session/s1/file/scene_000.jpg',
        descriptionMy: 'ဂိုဒေါင်ထဲမှာ လူနှစ်ယောက် ထိပ်တိုက်တွေ့နေကြသည်',
      },
    ],
    storyAnalysisMy: 'စာရင်းစာအုပ်လုယူမှုနှင့် ခြိမ်းခြောက်ခန်း',
  });

  assert.equal(targetDurationSeconds, 54);
  assert.ok(systemInstruction.includes('MIXED'));
  assert.ok(systemInstruction.includes('TARGET_WORDS'));
  assert.ok(prompt.includes('54.00 seconds (~90%'));
  assert.ok(prompt.includes('[00:01.20 -> 00:04.50] "Where did you hide the ledger?"'));
  assert.ok(prompt.includes('[00:04.80 -> 00:08.40] "If you step closer, nobody leaves alive!"'));
  assert.equal(prompt.includes('MAX_WORDS'), false);
  assert.ok(prompt.includes('DO NOT invent'));
  assert.ok(prompt.includes('Never copy or reuse phrasing from prompt instructions'));
});

test('formatTimestampedTranscriptContext deduplicates consecutive echoes and sorts chronologically', () => {
  const formatted = formatTimestampedTranscriptContext(
    [
      { start: 6.0, end: 8.0, text: 'Second line' },
      { start: 1.0, end: 3.0, text: 'First line' },
      { start: 1.5, end: 3.5, text: 'First line' },
    ],
    10
  );
  const lines = formatted.split('\n');
  assert.equal(lines.length, 2);
  assert.ok(lines[0].startsWith('[00:01.00 -> 00:03.50] "First line"'));
  assert.ok(lines[1].startsWith('[00:06.00 -> 00:08.00] "Second line"'));
});

test('countSpokenUnits & estimateMyanmarTextDurationSeconds count Burmese syllables accurately including conjuncts and speed', () => {
  const units = countSpokenUnits('မိုးရွာနေတဲ့ တံတားပေါ်မှာ စုံထောက်ကြီး သတ္တိရှိရှိ စောင့်နေတယ်။');
  assert.ok(units.myanmarSyllables >= 19 && units.myanmarSyllables <= 23);

  const normal = estimateMyanmarTextDurationSeconds(
    'စုံထောက်ကြီးက တရားခံကို မေးခွန်းထုတ်လိုက်ပြီး အမှန်တရားကို ဖော်ထုတ်ဖို့ ကြိုးစားနေပါတယ်။',
    'normal'
  );
  const fast = estimateMyanmarTextDurationSeconds(
    'စုံထောက်ကြီးက တရားခံကို မေးခွန်းထုတ်လိုက်ပြီး အမှန်တရားကို ဖော်ထုတ်ဖို့ ကြိုးစားနေပါတယ်။',
    'fast'
  );
  const slow = estimateMyanmarTextDurationSeconds(
    'စုံထောက်ကြီးက တရားခံကို မေးခွန်းထုတ်လိုက်ပြီး အမှန်တရားကို ဖော်ထုတ်ဖို့ ကြိုးစားနေပါတယ်။',
    'slow'
  );

  assert.ok(normal.estimatedSeconds > 3.5);
  assert.ok(fast.estimatedSeconds < normal.estimatedSeconds);
  assert.ok(slow.estimatedSeconds > normal.estimatedSeconds);
});

test('selectRecapBeatsForAutoExpansion targets ONLY underfilled beats with transcript/scene evidence and never invents when evidence is absent', () => {
  const rawSegments = [
    { start: 0.5, end: 5.5, text: 'Where did you hide the key? Tell me now!' },
    { start: 6.5, end: 11.5, text: 'If you open that door, the whole building explodes!' },
  ];
  const beats = buildFullRecapBeats(rawSegments, 24, 'normal');
  assert.ok(beats.length >= 4);

  // Make beat_1 richly detailed, leave remaining beats super short/underfilled
  const sparseSegments = beats.map((b, idx) => ({
    id: b.id,
    myanmarText:
      idx === 0
        ? "အခန်းထဲဝင်လာတဲ့ စုံထောက်က တရားခံကို စူးစိုက်ကြည့်ပြီး 'သော့ကို ဘယ်မှာဖွက်ထားလဲ အခုပြောစမ်း' လို့ ဒေါသတကြီး မေးလိုက်ပါတယ်။"
        : 'ဆက်ပြောတယ်။',
    emoji: '🎬',
  }));

  const expansion = selectRecapBeatsForAutoExpansion({
    beats,
    segments: sparseSegments,
    videoDurationSeconds: 24,
    voiceSpeed: 'normal',
    timestampedSegments: rawSegments,
    transcript: rawSegments.map((s) => s.text).join(' '),
  });

  assert.equal(expansion.shouldExpand, true);
  assert.ok(expansion.estimate.coverageRatio < 0.78);
  // beat_1 is already full, so it must NOT be selected for expansion
  assert.equal(
    expansion.candidates.some((c) => c.beat.id === 'beat_1'),
    false
  );
  assert.ok(expansion.candidates.length >= 1);

  const expandPrompt = buildRecapAutoExpansionPrompt({
    durationSeconds: 24,
    targetDurationSeconds: expansion.estimate.targetDurationSeconds,
    currentEstimatedSeconds: expansion.estimate.estimatedDurationSeconds,
    candidates: expansion.candidates,
  });
  assert.ok(expandPrompt.prompt.includes('DO NOT repeat its content'));
  assert.ok(expandPrompt.prompt.includes('NEVER fabricate dialogue'));

  // Without transcript or visual scenes, auto-expansion MUST NOT invent content
  const noEvidenceBeats = buildFullRecapBeats([], 24, 'normal');
  const noEvidenceExpansion = selectRecapBeatsForAutoExpansion({
    beats: noEvidenceBeats,
    segments: noEvidenceBeats.map((b) => ({ id: b.id, myanmarText: 'တိုတို', emoji: '🎬' })),
    videoDurationSeconds: 24,
    voiceSpeed: 'normal',
    timestampedSegments: [],
    scenes: [],
    transcript: '',
  });
  assert.equal(noEvidenceExpansion.shouldExpand, false);
  assert.equal(noEvidenceExpansion.candidates.length, 0);
});

test('validateAndRefineRecapSegments cleans labels, deduplicates repeated dialogue, and tracks coverage & quotes', () => {
  const beats = buildFullRecapBeats(
    [
      { start: 0.5, end: 5.0, text: 'Who sent you here?' },
      { start: 5.5, end: 11.5, text: 'You cannot stop what is coming.' },
    ],
    12,
    'normal'
  );

  assert.equal(
    cleanRecapSpokenText("Narration: ကောင်လေးက ဝင်လာပြီး Dialogue: 'မင်းဘာလို့လာတာလဲ' လို့မေးတယ်။"),
    "ကောင်လေးက ဝင်လာပြီး 'မင်းဘာလို့လာတာလဲ' လို့မေးတယ်။"
  );

  const repeatedClause = "သူက 'မင်းဒီကနေ ထွက်ပြေးလို့ မလွတ်ဘူး' လို့ ခြိမ်းခြောက်လိုက်တယ်။";
  const validation = validateAndRefineRecapSegments({
    beats,
    rawSegments: beats.map((b, idx) => ({
      id: b.id,
      myanmarText:
        idx === 0
          ? `Narration: အစပိုင်းမှာတော့ သူတို့နှစ်ယောက် ထိပ်တိုက်တွေ့ကြတယ်။ ${repeatedClause}`
          : idx === 1
            ? `${repeatedClause} နောက်တော့ သူလည်း ကြောက်လန့်ပြီး နောက်ဆုတ်သွားခဲ့တယ်။`
            : 'နောက်ဆုံးမှာတော့ အမှန်တရားတစ်ခုလုံး ပေါ်ပေါက်သွားပါတော့တယ်။',
      emoji: '🔥',
    })),
    videoDurationSeconds: 12,
    voiceSpeed: 'normal',
  });

  assert.equal(validation.segments.length, beats.length);
  assert.equal(validation.removedDuplicateCount, 1);
  assert.equal(validation.dialogueLineCount, 1);
  assert.equal(validation.segments[0].myanmarText.includes('Narration:'), false);
  assert.equal(validation.segments[1].myanmarText.includes('မင်းဒီကနေ ထွက်ပြေးလို့ မလွတ်ဘူး'), false);

  const coverage = estimateRecapNarrationCoverage(beats, validation.segments, 12, 'normal');
  assert.equal(coverage.targetDurationSeconds, 10.8);
  assert.ok(coverage.estimatedDurationSeconds > 4);
});

test('extractVerifiedCharacterClues identifies speaker turns, titles/ranks, and vocatives while filtering non-names', () => {
  const clues = extractVerifiedCharacterClues({
    transcript: [
      'Detective Miller: Where did you hide the ledger, Marcus?',
      'Marcus: Wait, please! Ask Dr. Chen if you do not believe me.',
      'Elena: Run, Marcus!',
    ].join('\n'),
    timestampedSegments: [
      { start: 0.5, end: 4.0, text: 'Detective Miller: Where did you hide the ledger, Marcus?' },
      { start: 4.2, end: 8.5, text: 'Marcus: Wait, please! Ask Dr. Chen if you do not believe me.' },
    ],
  });

  const names = clues.map((c) => c.canonicalName);
  assert.ok(names.includes('Detective Miller'));
  assert.ok(names.includes('Marcus'));
  assert.ok(names.includes('Dr. Chen'));
  assert.ok(names.includes('Elena'));
  assert.equal(names.some((n) => /^(Wait|Please|Run|Ask)$/i.test(n)), false);

  // When no character names exist in transcript/scenes, return empty roster (never invent)
  const emptyClues = extractVerifiedCharacterClues({
    transcript: 'Someone walks down the street at night without saying any names.',
  });
  assert.equal(emptyClues.length, 0);
});

test('auditRecapCharacterConsistency & prompts enforce real names over generic pronouns and trigger pre-final check only when needed', () => {
  const timestampedSegments = [
    { start: 0.5, end: 5.0, text: 'Captain Park: Stay back, Mina!' },
    { start: 5.5, end: 11.0, text: 'Mina: Captain Park, the vault is already open!' },
  ];
  const verifiedCharacters = extractVerifiedCharacterClues({ timestampedSegments });
  const beats = buildFullRecapBeats(timestampedSegments, 12, 'normal');

  const promptBundle = buildRecapMixedNarrationPrompt({
    durationSeconds: 12,
    transcript: timestampedSegments.map((s) => s.text).join(' '),
    timestampedSegments,
    voiceStyleName: 'Street Bro',
    voiceStyleTag: 'Natural',
    voiceStyleDesc: 'Conversational',
    speedNote: 'Use TARGET_WORDS',
    beatListText: beats.map((b) => `- Beat id="${b.id}"`).join('\n'),
    beatCount: beats.length,
    verifiedCharacters,
  });

  assert.ok(promptBundle.prompt.includes('Captain Park'));
  assert.ok(promptBundle.prompt.includes('Mina'));
  assert.ok(promptBundle.prompt.includes('CHARACTER NAME & IDENTITY CONSISTENCY'));
  assert.ok(promptBundle.prompt.includes('ရဲအရာရှိ'));

  // Draft relying heavily on generic pronouns & missing Mina triggers consistency pass
  const pronounHeavyDraft = [
    { id: beats[0].id, myanmarText: 'သူက အဲဒီလူကို ကြည့်ပြီး သူမကို နောက်ဆုတ်ဖို့ ပြောလိုက်တယ်။', emoji: '🎬' },
    { id: beats[1].id, myanmarText: 'သူမက သူ့ကို ကြည့်ပြီး တံခါးပွင့်နေပြီလို့ ပြန်ပြောတယ်။', emoji: '😱' },
    { id: beats[2].id, myanmarText: 'သူတို့နှစ်ယောက် အထဲကို ပြေးဝင်သွားကြတယ်။', emoji: '🔥' },
  ];
  const badAudit = auditRecapCharacterConsistency(pronounHeavyDraft, verifiedCharacters);
  assert.equal(badAudit.needsConsistencyPass, true);
  assert.ok(badAudit.missedKnownNames.includes('Captain Park'));
  assert.ok(badAudit.missedKnownNames.includes('Mina'));

  const consistencyPrompt = buildRecapCharacterConsistencyPrompt({
    beats,
    segments: pronounHeavyDraft,
    verifiedCharacters,
    audit: badAudit,
    timestampedSegments,
  });
  assert.ok(consistencyPrompt.prompt.includes('Captain Park'));
  assert.ok(consistencyPrompt.prompt.includes('Mina'));

  // Once names are consistently preserved across beats, consistency pass is not needed
  const cleanDraft = [
    { id: beats[0].id, myanmarText: "Captain Park က Mina ကို 'နောက်ဆုတ်နေပါ' လို့ သတိပေးလိုက်တယ်။", emoji: '🎬' },
    { id: beats[1].id, myanmarText: "Mina က Captain Park ကို 'ဘဏ်တိုက်တံခါးက ပွင့်နေပြီ' လို့ ထိတ်လန့်တကြီး ပြန်ပြောတယ်။", emoji: '😱' },
    { id: beats[2].id, myanmarText: 'Captain Park နဲ့ Mina တို့ အထဲကို သတိကြီးကြီးနဲ့ ဝင်သွားကြတယ်။', emoji: '🔥' },
  ];
  const cleanAudit = auditRecapCharacterConsistency(cleanDraft, verifiedCharacters);
  assert.equal(cleanAudit.needsConsistencyPass, false);
  assert.equal(cleanAudit.missedKnownNames.length, 0);
});

test('buildRecapMixedNarrationPrompt enforces 9 narrative stages, FULL ENDING, and 1.0x locked video speed', () => {
  const { systemInstruction, prompt } = buildRecapMixedNarrationPrompt({
    durationSeconds: 173,
    transcript: 'Captain Park: "Hold the gate!"',
    timestampedSegments: [{ start: 1.0, end: 5.0, text: 'Captain Park: Hold the gate!' }],
    voiceStyleName: 'Street Bro',
    voiceStyleTag: 'Natural',
    voiceStyleDesc: 'Conversational',
    speedNote: 'Natural pacing',
    beatListText: '- Beat id="beat_1" (scene_1) [0.00s -> 15.00s, STAGE=1. Opening Hook, TARGET_WORDS=34]: "Gate tension"',
    beatCount: 1,
    scenes: [
      {
        index: 0,
        sceneId: 'scene_1',
        timestamp: 2.0,
        startTime: 0,
        endTime: 15,
        characters: ['Captain Park'],
        actions: ['Guards the vault'],
        dialogueRef: 'Hold the gate!',
        storyEvent: 'Captain Park defends the vault entrance.',
        imageUrl: '/scene_000.jpg',
        descriptionMy: 'Captain Park က တံခါးဝကို စောင့်ကြပ်နေသည်။',
      },
    ],
  });

  assert.ok(systemInstruction.includes('1.0x video speed'));
  assert.ok(prompt.includes('Recap Style = DETAILED | Ending Style = FULL ENDING'));
  assert.ok(prompt.includes('1. Opening Hook'));
  assert.ok(prompt.includes('9. Full Ending and Resolution'));
  assert.ok(prompt.includes('Video Speed LOCKED at 1.0x'));
  assert.ok(prompt.includes('155.70 seconds'));
  assert.ok(prompt.includes('[scene_1 | 00:00.00 -> 00:15.00]'));
});

test('distributeEditedScriptAcrossBeats, buildRecapSceneMappings, buildRecapDurationAdjustmentPrompt, and validateRecapQuality work together for 173s video & block invalid speed/silence cuts', () => {
  const scenes = Array.from({ length: 12 }, (_, idx) => ({
    index: idx,
    sceneId: `scene_${idx + 1}`,
    timestamp: idx * 14 + 3,
    startTime: Number(((idx * 173) / 12).toFixed(2)),
    endTime: Number((((idx + 1) * 173) / 12).toFixed(2)),
    imageUrl: `/scene_${idx}.jpg`,
    characters: ['Captain Park', 'Mina'],
    storyEvent: `အခန်း ${idx + 1} ဖြစ်စဉ်`,
    descriptionMy: `Captain Park နဲ့ Mina အခန်း ${idx + 1} မှာ လှုပ်ရှားနေကြတယ်။`,
  }));

  const timestamped = [
    { start: 3, end: 9, text: 'Captain Park: Mina, stay behind me!' },
    { start: 158, end: 170, text: 'Mina: Captain Park, everything is finally over.' },
  ];
  const beats = buildFullRecapBeats(timestamped, 173, 'normal', { scenes, maxBeats: 24 });
  assert.equal(beats.length, 12);

  // Manual script edit across multiple Burmese sentences preserves all 12 scene windows
  const manualEditedScript = beats
    .map(
      (_, i) =>
        i === 0
          ? "Captain Park က Mina ကို 'နောက်မှာနေပါ' လို့ သတိပေးရင်း အမှုကို စတင်စစ်ဆေးနေတယ်။"
          : `Captain Park နဲ့ Mina တို့ အခန်း (${i + 1}) ထဲက သဲလွန်စကို အတူတကွ ဆက်လက်ဖော်ထုတ်နေကြတယ်။`
    )
    .join(' ');

  const distributed = distributeEditedScriptAcrossBeats(manualEditedScript, beats);
  assert.equal(distributed.length, 12);
  assert.ok(distributed[0].myanmarText.includes('Captain Park'));

  const rawDurs: Record<string, number> = {};
  const textsById: Record<string, string> = {};
  beats.forEach((b, i) => {
    rawDurs[b.id] = Number((b.duration * 0.9).toFixed(2));
    textsById[b.id] = distributed[i].myanmarText;
  });

  const schedule = computeLockedVideoRecapSchedule(beats, rawDurs, 173, { textsById });
  const mappings = buildRecapSceneMappings({
    beats,
    segments: distributed,
    scenes,
    verifiedCharacters: [
      { canonicalName: 'Captain Park', aliases: [], roleOrRelation: 'Captain', evidenceSource: 'transcript' },
      { canonicalName: 'Mina', aliases: [], roleOrRelation: '', evidenceSource: 'transcript' },
    ],
    schedule,
  });

  assert.equal(mappings.length, 12);
  assert.equal(mappings[0].sceneId, 'scene_1');
  assert.equal(mappings[0].storyStage, 'opening_hook');
  assert.ok(mappings[0].dialogueText?.includes('နောက်မှာနေပါ'));
  assert.equal(mappings[11].sceneId, 'scene_12');
  assert.equal(mappings[11].storyStage, 'full_ending');

  const validGate = validateRecapQuality({
    beats,
    segments: distributed,
    mappings,
    originalVideoDuration: 173,
    actualTtsDuration: schedule.actualFittedTtsDuration,
    videoPlaybackRate: 1.0,
    silenceCutApplied: false,
    verifiedCharacters: [
      { canonicalName: 'Captain Park', aliases: [], roleOrRelation: 'Captain', evidenceSource: 'transcript' },
      { canonicalName: 'Mina', aliases: [], roleOrRelation: '', evidenceSource: 'transcript' },
    ],
    timestampedSegments: timestamped,
    hasTtsAudio: true,
  });

  assert.equal(validGate.canRender, true);
  assert.equal(validGate.passed, true);
  assert.equal(validGate.videoSpeedLocked, 1.0);
  assert.equal(validGate.fullEndingCovered, true);
  assert.equal(validGate.targetRecapDuration, 155.7);

  // Critical block: if videoPlaybackRate != 1.0 or silenceCutApplied is true -> canRender MUST be false!
  const blockedSpeedGate = validateRecapQuality({
    beats,
    segments: distributed,
    mappings,
    originalVideoDuration: 173,
    actualTtsDuration: schedule.actualFittedTtsDuration,
    videoPlaybackRate: 1.45,
    silenceCutApplied: true,
    hasTtsAudio: true,
  });
  assert.equal(blockedSpeedGate.canRender, false);
  assert.ok(blockedSpeedGate.criticalErrors.some((e) => e.includes('1.0x')));

  // Actual duration adjustment prompt includes measured seconds + expand/tighten instruction
  const adjPrompt = buildRecapDurationAdjustmentPrompt({
    durationSeconds: 173,
    actualTotalTtsSeconds: 98.4,
    targetTotalTtsSeconds: 155.7,
    targets: [
      {
        beat: beats[0],
        mode: 'expand',
        currentText: distributed[0].myanmarText,
        currentEmoji: '🎬',
        actualTtsSeconds: 3.1,
        targetTtsSeconds: 12.9,
        maxWindowSeconds: 14.4,
        matchingTranscriptLines: ['[00:03 -> 00:09] "Captain Park: Mina, stay behind me!"'],
        matchingSceneNotes: ['[00:03] Captain Park checks the gate.'],
        previousBeatText: '',
        nextBeatText: distributed[1].myanmarText,
      },
    ],
  });
  assert.ok(adjPrompt.prompt.includes('98.40s'));
  assert.ok(adjPrompt.prompt.includes('155.70s'));
  assert.ok(adjPrompt.prompt.includes('EXPAND'));
});
